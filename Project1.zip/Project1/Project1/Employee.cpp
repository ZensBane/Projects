//CS3100 / Data Structures and Algorithms, Ben Small, Meilin Liu, 9/15/20, and the project1. 
//Ben Small
//Small17@wright.edu
//#define friend
#include "Employee.h"
using namespace std;
#include <string>
#include <cstdlib>
#include <iostream>
//functions go here (constructors / destructor)

Employee::Employee(int IdNum, string last, string first) {
	ID = IdNum;
	lastname = last;
	firstname = first;
}

Employee::Employee(const Employee& person) {
	ID = person.ID;
	lastname = person.lastname;
	firstname = person.firstname;
}

Employee::~Employee() {

}

void Employee::setFirstName(string first) {
	this->firstname = first;
}

void Employee::setLastName(string last) {
	this->lastname = last;
}

void Employee::setID(int IdNum) {
	this->ID = IdNum;

}

int Employee::getID() const {
	return this->ID;

}

string Employee::getFirstName() const {
	return this->firstname;
}

string Employee::getLastName() const{

	return this->lastname;
}

istream& operator>>(istream& ins, Employee& person) {

	return ins;
}

ostream& operator<<(ostream& outs, const Employee& person) {
	return outs;
}


bool operator==(const Employee& p1, const Employee& p2) {
	if (p1.getFirstName() == p2.getFirstName() && p1.getLastName() == p2.getLastName() && p1.getID() == p2.getID()) {
		return true;
	}
	else {
		return false;
	}
}

bool operator<(const Employee& p1, const Employee& p2) {
	if (p1.getID() < p2.getID()) {
		return true;
	}
	else {
		return false;
	}
}