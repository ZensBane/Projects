//CS3100 / Data Structures and Algorithms, Ben Small, Meilin Liu, 9/15/20, and the project1. 
//Ben Small
//Small17@wright.edu
// Project1.cpp : This file contains the 'main' function. Program execution begins and ends there.

#include <iostream>
#include <fstream>
#include <string>
#include "Employee.h"
using namespace std;

int main()
{
    ifstream inFile;
    inFile.open("SmallDatabase.txt");
    ofstream outFile;
    outFile.open("outFile.txt");
    bool resume = true;                                                                              //repeating clause to make program run until told to stop for ease of grading.
    while (resume == true){
        cout << "Please select 1 - 5.\n";
        cout << "1) Read an employee record from the keyboard, and display it on the screen, and write it to the output file simultaneously.\n";
        cout << "2) Read a specified number of the employee records from the input file, display them on the screen, and write them to the output file simultaneously (specified from the keyboard (range of 1 - 99)).\n";
        cout << "3) Read two employee records from the keyboard, and test if these two employees are the same.\n";
        cout << "4) Read two employee records from the input file, and test if one employee's ID is less than another employee's ID.\n";
        cout << "5) Quit\n";
        char input;
        int choice = 0;
        cin >> input;
        cout << input << "\n";
        if (input == '1') {                                                                             //next few lines convert the input to a int value.
            choice = 1;
        }else if (input == '2') {
            choice = 2;
        }else if (input == '3') {
            choice = 3;
        }else if (input == '4') {
            choice = 4;
        }else if (input == '5') {
            choice = 5;
        }else{
            while (input != '1' && input != '2' && input != '3' && input != '4' && input != '5') {      //ensures correct input
                cout << "Invalid input, please input a number 1 through 5.\n";
                cin >> input;
                cout << input << "\n";
                if (input == '1') {
                    choice = 1;
                }else if (input == '2') {
                    choice = 2;
                }else if (input == '3') {
                    choice = 3;
                }else if (input == '4') {
                    choice = 4;
                }else if (input == '5') {
                    choice = 5;
                }
            }
        }
        cout << "Valid input received. input was " << input << ".\n";
        if (choice == 1) {
            string last;
            string first;
            int ID;
            cout << "Please input last name:\n";
            cin >> last;
            cout << "Please input first name:\n";
            cin >> first;
            cout << "Please input employee Id:\n";
            cin >> ID;
            cout << last << " " << first << " " << ID << "\n";
            Employee emp1 = Employee(ID, last, first);
            outFile << emp1.getLastName() << " " << emp1.getFirstName() << " " << emp1.getID() << "\n";
        }
        else if (choice == 2) {
            inFile.close();                                                     //closes prevous file
            inFile.open("SmallDatabase.txt");                                   //opens SmallDatabase.txt
            outFile.close();                                                    //closes previous file
            outFile.open("outFile.txt");
            cout << "please specify a start range of employees to be read from the input file to the output file:\n";
            int range;                                                          //sets up start range
            int count = 0;                                                      //sets up a counter for reading characters
            cin >> range;                                                       //input for start range
            cout << "Please input an end range:\n";             
            int endRange;                                                       //end range
            cin >> endRange;                                                    //input for end range
            int counter = 0;                                                    //sets up a line counter
            if (range != 1) {                                                   //a trigger in case the start range is not 1
                inFile.seekg(count);                                            //sets a pointer for the file reader
                while(counter != range) {                                       //loops till the start range is found
                    if (inFile.peek() == '\n') {                                //checks for next line
                        counter++;                                              //adds a lione counter
                    }
                    count++;                                                    //adds a letter counter
                    inFile.seekg(count);                                        //sets the pointer to next character
                }
            }
            if (range %2 != 0 && range != 1) {                                  //a fix for a small bug that occurs almost randomly. further development may be needed
                count = count++;
            }
            inFile.close();                                                     
            inFile.open("SmallDatabase.txt");
            inFile.seekg(count + 1);                                            //sets the pointer ahead one
            int range2 = count;                                                 //sets up a placeholder to keep track of pointer
            bool range3 = true;                                                 //a safety trigger to prevent repeating characters
            char car = inFile.peek();                                           //sets sights on next character
            while (inFile.peek() != NULL && range != endRange + 1){             //repeats till no characters are found or reaches the end range limit
                if (car == '\n') {                                              //end of line
                    if (range3 == true) {                                       //fires safety trigger
                        range++;                                                //gets range closer to end range
                        range3 = false;                                         //turns on safety trigger
                    }
                    //next two repeat a lot
                    inFile.seekg(range2);                                       //tells pointer where to look
                    car = inFile.peek();                                        //looks at the next character
                    range2++;                                                   //sets forward the looking pointer
                }else {
                    if (range3 == false) {                                      //first letter found of newline
                        car = inFile.get();                                     //gets the first character of newline
                        cout << car;                                            //outputs the letter
                        outFile << car;                                         //writes the character to outfile
                    }
                    range3 = true;                                              //turns off safety trigger
                    inFile.seekg(range2);                                       
                    car = inFile.peek();
                    cout << car;
                    outFile << car;
                    range2++;
                }
            }
        }else if (choice == 3) {
            cout << "Please input employee 1:(input as last)\n";
            string empl1last;
            cin >> empl1last;                                                   //inputs for the lastname
            cout << "Please input employee 1:(input as first)\n";
            string empl1first;
            cin >> empl1first;                                                  //inputs for the firstname
            cout << "Please input employee 1:(input as ID)\n";
            int empl1id;
            cin >> empl1id;                                                     //inputs for employee id
            Employee emp1(empl1id, empl1last, empl1first);                      // puts the data into the employee object

                                                                                //repeats for a second employee
            cout << "Please input employee 2:(input as last)\n";
            string empl2last;
            cin >> empl2last;
            cout << "Please input employee 2:(input as first)\n";
            string empl2first;
            cin >> empl2first;
            cout << "Please input employee 2:(input as ID)\n";
            int empl2id;
            cin >> empl2id;
            Employee emp2(empl2id, empl2last, empl2first);
            if (emp1 == emp2) {                                                 //checks to see if both employees are the same
                cout << true << "true" << '\n';
            }else {
                cout << false << "false" <<'\n';
            }
        }
        else if (choice == 4) {
            cout << "Please input filename to be read:\n";
            inFile.close();
            string fileName;
            cin >> fileName;    
            inFile.open(fileName);                                              //opens the specified file.
            int counter = 0;                                                    //a character countere.
            Employee emp1;
            string name;                                                        //a string storage
            int number;                                                         //a storage number for ID
            string c;
            inFile.seekg(0);                                                    //tells a pointer where to read.
            while (inFile.peek() != ' ') {                                      //gets only lastname
                c = inFile.peek();                                              //gets character
                name.append(c);                                                 //adds the character to storage string
                counter++;                                                      //adds to character counter
                inFile.seekg(counter);                                          //tells the pointer to look at the next character
            }
            emp1.setLastName(name);                                             //sets the storage string as the lastname
            counter++;                                                          //moves the character pointer forward one
            inFile.seekg(counter);                                              //sets the pointer.
            name = "";                                                          //clears the name storage.
                                                                                
                                                                                //repeat for firstname
            while (inFile.peek() != ' ') {  
                c = inFile.peek();
                name.append(c);
                counter++;
                inFile.seekg(counter);
            }
            emp1.setFirstName(name);
            counter++;
            inFile.seekg(counter);
            name = "";
            number = 0;                                                         //a storage counter for ID
            int trans;                                                          //a storage int for the next number
            while (inFile.peek() != '\n') {                                     //scans until end of line
                c = inFile.peek();                                              //gets the next number (or first)
                if (c == "0") {                                                 //convertion of numbers
                    trans = 0;
                }else if (c == "1") {
                    trans = 1;
                }else if (c == "2") {
                    trans = 2;
                }else if (c == "3") {
                    trans = 3;
                }else if (c == "4") {
                    trans = 4;
                }else if (c == "5") {
                    trans = 5;
                }else if (c == "6") {
                    trans = 6;
                }else if (c == "7") {
                    trans = 7;
                }else if (c == "8") {
                    trans = 8;
                }else if (c == "9") {
                    trans = 9;
                }
                number = number * 10;                                            //shifts the number over left one digit
                number = number + trans;                                         //adds the new number
                counter++;
                inFile.seekg(counter);
            }
            emp1.setID(number);                                                  //sets the employee ID as number
            cout << emp1;
            counter++;
            inFile.seekg(counter);
                                                                                 //repeat above for employee 2
            Employee emp2;
            while (inFile.peek() != ' ') {
                c = inFile.peek();
                name.append(c);
                counter++;
                inFile.seekg(counter);
            }
            emp2.setLastName(name);
            counter++;
            inFile.seekg(counter);
            name = "";
            while (inFile.peek() != ' ') {
                c = inFile.peek();
                name.append(c);
                counter++;
                inFile.seekg(counter);
            }
            emp2.setFirstName(name);
            counter++;
            inFile.seekg(counter);
            name = "";
            number = 0;
            while (inFile.peek() != '\n' && inFile.peek() != NULL) {
                c = inFile.peek();
                if (c == "0") {
                    trans = 0;
                }else if (c == "1") {
                    trans = 1;
                }else if (c == "2") {
                    trans = 2;
                }else if (c == "3") {
                    trans = 3;
                }else if (c == "4") {
                    trans = 4;
                }else if (c == "5") {
                    trans = 5;
                }else if (c == "6") {
                    trans = 6;
                }else if (c == "7") {
                    trans = 7;
                }else if (c == "8") {
                    trans = 8;
                }else if (c == "9") {
                    trans = 9;
                }
                number = number * 10;
                number = number + trans;
                counter++;
                inFile.seekg(counter);
            }
            emp2.setID(number);
            cout << emp2;

                                                                            //evaluates the two employee IDs
            if (emp1.getID() < emp2.getID()) {
                cout << "less than";
                cout << "\n";
            }
            else {
                cout << "greater or equal to";
                cout << "\n";
            }
        }
        else {                  //choice must be 5
            inFile.close();                                                 //closes infile
            outFile.close();                                                //closes outfile
            resume = false;                                                 //turns off the repeating clause
        }
    }
}