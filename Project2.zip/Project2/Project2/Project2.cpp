//CS3100 / Data Structures and Algorithms, Ben Small, Meilin Liu, 10/7/20, and the project2. 
//Ben Small
//Small17@wright.edu
#include <iostream>
#include <fstream>
#include <string>
#include "SStack.h"

int main()
{
    ifstream inFile;
    inFile.open("all.last.txt");
    cout << "The first test will be the construction operator, here the stack will be created.\n";
    SStack s1 = SStack(10);
    cout << "The second test will be for the isEmpty function, as there has been no input the result should be true (1).\n";
    cout << s1.IsEmpty();
    cout << "\nThis test is for the top function, which should return the stack is empty as nothing has been pushed.\n";
    cout << s1.top();
    cout << "This test will print the size of the stack.\n";
    cout << s1.size() << "\n";
    cout << "The next test will be for receiving input from a file that we were given named all.last.\n";
    int counter = 0;                //this counter is for tracking the pointer of file reader
    int NameCount = 0;              //this counter is for counting the number of names
    inFile.seekg(counter);          //sets a pointer for the file reader
    string name;
    while (NameCount <= s1.getCapacity() - 1) {
        if (inFile.peek() == NULL) {   //checks the file to ensure it doesn't wait for more input than available
            NameCount = s1.getCapacity();
        }
        else {
            char car = inFile.get();    //reads the current character amd sets it to car
            name = name + car;          //writes the name to name
            if (inFile.get() == '\n') { //triggers at the end of every name
                s1.push(name + "\n");          //adds the name to the stack
                name = "";              //empties out name
                NameCount++;            //increases counter
                counter++;
            }
        }
        counter++;                      //increases the counter for the pointer.
        inFile.seekg(counter);          //moves the pointer forward
    }
    cout << "\n";
    cout << "The next test will be print, this should print the whole stack.\n";
    s1.print();
    cout << "The next test is the isEmpty function again which should now display (0) as there is data in the stack.\n";
    cout << s1.IsEmpty();
    cout << "\nSeeing that there is data in the stack this next test is for top function again. expected SMITH\n";
    cout << s1.top();
    cout << "Now testing the pop function followed by the print function. expected SMITH\n";
    s1.pop();
    cout << "Printing.\n";
    s1.print();
    cout << "testing the copy constructor followed by a pop.\n";
    SStack s2 = SStack(s1);
    s2.pop();
    cout << "Now testing the equal opperator which should come out flase as I just popped from the coppied stack.\n";
    cout << equals(s1, s2)<< "\n";
    s2.push("Steve\n");
    cout << "Now testing the union function and printing the result which should be steve plus stack 1. The result will show after a |||| line. ignore the pops.\n";
    SStack s3 = s1 + s2;
    cout << "|||||||||||||||||||||||||||||||||\n";
    s3.print();
    cout << "Lastly testing the destructor function. Followed is a print which should come up blank.\n";
    s1.~SStack();
    s1.print();
    inFile.close();
}
