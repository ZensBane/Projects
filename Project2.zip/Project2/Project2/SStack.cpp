//CS3100 / Data Structures and Algorithms, Ben Small, Meilin Liu, 10/7/20, and the project2. 
//Ben Small
//Small17@wright.edu
#include "SStack.h"
#include <cstdlib>
#include <string>
#include <iostream>
#include <stack>
using namespace std;
SStack::SStack(int cap) {
	Capacity = cap;
	DynamicStack = new string[cap];
	used = 0;
	
}
SStack::SStack(const SStack& s) {			//copy constructor
	this->Capacity = s.Capacity;			//sets up the new capacity
	int i = 0;								
	DynamicStack = new string[s.Capacity];
	while (i <= s.Capacity - 1) {			//copies all values from 
		DynamicStack[i] = s.DynamicStack[i];
		i++;
	}
	this->used = s.used;
}

SStack::~SStack() {							//destructor
	DynamicStack->clear();
	used = NULL;
	Capacity = NULL;
}
void SStack::push(const std::string s) {
	if (this->used >= this->Capacity) {		//checks how full the stack is
		cout << "Stack is full\n";			
	}
	else {									//if the stack is not full then fills in the next spot
		this->DynamicStack[used] = s;
		used++;
	}
}
string SStack::pop(){
	bool check;								//sets a value to be the flag
	check = this->IsEmpty();
	if (check == true) {					//flag was triggered the stack is empty
		return "Stack is emtpy\n";
	}
	else {									//no flag there is data in the stack
		string store = this->DynamicStack[0];//saves the current value at the top
		int i = 0;							//a loop counter
		while (DynamicStack[i] != "" && i + 1 != Capacity) {//loop for moving each value in the stack
			DynamicStack[i] = DynamicStack[i + 1];			//moves each value in the stack
			i++;
		}
		this->DynamicStack[i] = "";
		used--;								//decreases the amount used
		cout << store << "\n";				//displays what is removed
		return store;						//returns what was removed
	}
}
string SStack::top() const{					//nearly the same as pop
	bool check;
	check = this->IsEmpty();
	if (check == true) {
		return "Stack is emtpy\n";
	}
	else {
		return this->DynamicStack[0];		// returns the top of the stack
	}
}
bool SStack::IsEmpty() const{				//checks to see if the stack is empty
	if (this->used == NULL || this->used == 0) {
		return true;
	}
	else {
		return false;
	}
}
void SStack::print() const{					//prints off all stack values
	int i = Capacity - 1;
	while (i >= 0) {						//repeats for stack size
		cout << this->DynamicStack[i];
		i--;
	}
}
int SStack::size() const{					//returns number of used values
	return used;
}
int SStack::getCapacity() const {			//just curious do you read these comments
	return this->Capacity;					//returns the capacity
}
SStack operator +( SStack& s1, SStack& s2) {
	SStack s4 = SStack(s1.getCapacity() + s2.getCapacity());					//the final stack
	SStack s3 = s1;							//creates a stack saver
	while (s1.IsEmpty() == false) {			//inserts stack 1
		s4.push(s1.pop());
	}
	s1 = s3;								//refreshes stack 1
	SStack s5 = s2;					//backup of s2
	cout << "\n";
	bool catcher = false;			//a flagger for a found value
	while (s5.IsEmpty() == false) {
		s3 = s1;					//resets s3
		while (s3.IsEmpty() == false && catcher == false) {	//checks flagger for a green light
			if (s3.top() != s5.top()) {			//checks the two values if they are alike
				s3.pop();						//not alike, move on to the next value
				if (s3.IsEmpty() == true) {		//if no next value insert the top of s5
//					cout << "hi" << s5.top();	//friendly message
						s4.push(s5.top());
						catcher = false;		//resets flagger
					s5.pop();					//moves on
				}
			}
			else {
				s5.pop();						//moves on
				catcher = true;					//triggers flagger
			}
		}
		catcher = false;
	}
	return s4;
}
bool equals(const SStack& s1, const SStack& s2) {
	SStack s3 = s1;								//juggle stacks
	SStack s4 = s2;
	if (s3.getCapacity() == s4.getCapacity()) {	//compares basics to make things faster first
		if (s3.size() == s4.size()) {
			int i = 1;							//loop counter
			while (i <= s3.getCapacity() - 1) {
				if (s3.top() != s4.top()) {
					return false;				//inconsitancy found
				}
				s3.pop();						//removes current tops
				s4.pop();
				i++;							//advances the check
			}
			return true;						//no inconsistancy found two stacks are identical
		}
	}
	return false;								//failed a check flagged for inconsistancy
}